module.export = {
    transpileDependencies: ['vuex-module-decorators']
}